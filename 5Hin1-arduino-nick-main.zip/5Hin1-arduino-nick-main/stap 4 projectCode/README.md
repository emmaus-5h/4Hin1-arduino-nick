## Code maken

In deze map zet je de Arduino-code (het .ino bestand) van je project.

De voorbeeldcode is een goede basis om mee te beginnen. Telkens als je iets hebt toegevoegd aan je code, dan zet je dat in deze map. 
