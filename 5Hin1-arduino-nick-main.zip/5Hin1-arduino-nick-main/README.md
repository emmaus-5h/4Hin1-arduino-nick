# 5HV-arduino-template
In deze repo bewaar je alle bestanden die je maakt voor de opdracht Arduino.

Inleveren van de opdracht doe je door alle laatste versies van je bestanden te kopieren naar de map "inleveren"

informatie over knop en led aansluiten:
https://arduino-lessen.nl

informatie over display aansluiten:
https://emmauscollege.github.io/informatica/robot/how-to-display.html
