## Je levert in door in deze map de bestanden uit andere mappen te kopieren
Je levert in:
1.	Een circuit/aansluitschema (.pdf of .jpg bestand) van je Arduino en alles wat je erop hebt aangesloten.
2.	Testprogramma (.ino bestand) dat laat zien dat alles wat je het aangesloten op je Arduino werkt.
3.	Een toestandsdiagram van je apparaat (.pdf of .jpg bestand).
4.	De gebruikte code (.ino bestand), inclusief Nederlandstalig commentaar. Als je stukjes code hebt overgenomen, dan staat erbij waar je het vandaan hebt.
5.	Een video met geluid (.mp4 of .mov van maximaal 20MB of .txt bestand met link naar youtube, maximaal 2 minuten) waarin je je apparaat demonstreert.

Je levert uiterlijk in op de datum die in de studiewijzer staat in.

Tip: Je kunt meerdere keren inleveren. Lever een dag voor de deadline alvast een versie in die (bijna) af is. Op die manier voorkom je dat je door onverwachte problemen niets kunt inleveren.  
