## Toestandsdiagram maken

In deze map zet je een tekening van je toestandsdiagram.

Je kunt een toestandsdiagram bijvoorbeeld als volgt maken
- in Powerpoint
- op papier en dan fotograferen (het is dan wel lastig om het netjes te doen)
- een schermafdruk van een schema dat je gemaakt hebt in draw.io
