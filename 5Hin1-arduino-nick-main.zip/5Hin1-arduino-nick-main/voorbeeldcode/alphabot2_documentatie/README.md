# Project Alphabot2

## Documentatie
- Documentatie van de fabrikant van de Alphabot2<br>
[https://www.waveshare.com/wiki/AlphaBot2-Ar](https://www.waveshare.com/wiki/AlphaBot2-Ar)

## test code
Je kunt diverse voorbeelden downloaden van de documentatie-pagina
Als je de .h en .cpp bestanden van de libraries die je nodig hebt in dezelfde map plaatst als je code, 
dan hoef je ze niet steeds te installeren op de computer 
(de geinstalleerde libraries op schoolcomputers worden gewist als je uitlogt)
Je kunt de libraries gebruiken door bovenaan je code de volgende opdracht op te nemen
(één regel per library, in verband met geheugengebruik enkel de libraries die je gebruikt opnemen)
```
#include "de_naam_van_jouw_library.h"
```

## project code
Gebruik toestandsdiagrammencode. Je kunt de code voor het auto-project aanpassen aan de alphabot2.

