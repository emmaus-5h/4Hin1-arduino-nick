# Voorbeeldcode

In de submappen vind je documentatie en voorbeeldcode voor de projecten waaruit je kunt kiezen. De code is concept, als er betere voorbeeldcode op basis van ervaringen in de klas, dan wordt deze in een aparte repo gedeeld door je docent.