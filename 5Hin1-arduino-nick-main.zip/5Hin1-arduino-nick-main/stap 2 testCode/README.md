## Test Code

In deze map zet je de test-code (het .ino bestand) voor je circuit.

De test-code is een ander programma dan je eindcode. De testcode laat snel zien dat alles werkt wat op je Arduino is aangesloten. Door de test-code in je Arduino te zetten kun je snel zien of je Arduino-circuit nog heel is.

De voorbeeldcode in deze repo is een goed begin van testcode. Je kunt die zelf afmaken en in deze map zetten.
